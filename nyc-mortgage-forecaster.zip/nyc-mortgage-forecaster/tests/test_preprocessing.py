import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "src"))
from preprocessing import monthly_mortgage_payment  # noqa: E402


def test_monthly_payment_positive():
    payment = monthly_mortgage_payment(home_value=500000, rate_pct=6.5)
    assert payment > 0


def test_monthly_payment_zero_rate():
    # With a 0% rate, payment should just be principal / n_payments
    payment = monthly_mortgage_payment(home_value=500000, rate_pct=0, down_pct=0.2, years=30)
    expected = (500000 * 0.8) / (30 * 12)
    assert abs(payment - expected) < 1e-6


def test_higher_rate_increases_payment():
    low = monthly_mortgage_payment(home_value=500000, rate_pct=3.0)
    high = monthly_mortgage_payment(home_value=500000, rate_pct=7.0)
    assert high > low


def test_down_payment_reduces_payment():
    low_down = monthly_mortgage_payment(home_value=500000, rate_pct=6.0, down_pct=0.05)
    high_down = monthly_mortgage_payment(home_value=500000, rate_pct=6.0, down_pct=0.30)
    assert high_down < low_down
