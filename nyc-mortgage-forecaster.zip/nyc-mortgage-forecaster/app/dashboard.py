"""
dashboard.py
------------
Streamlit app to explore historical and forecasted NYC mortgage
affordability, and to let a user plug in their own income/down-payment
to see a personalized projection.

Usage:
    streamlit run app/dashboard.py
"""

import os
import sys
import pandas as pd
import streamlit as st

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "src"))
from preprocessing import monthly_mortgage_payment  # noqa: E402

PROCESSED_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")
HIST_PATH = os.path.join(PROCESSED_DIR, "affordability_dataset.csv")
FORECAST_PATH = os.path.join(PROCESSED_DIR, "forecast_10yr.csv")

st.set_page_config(page_title="NYC Mortgage Affordability Forecaster", layout="wide")
st.title("🏙️ NYC Mortgage Affordability Forecaster")
st.caption(
    "Historical and 10-year forecasted mortgage affordability, driven by "
    "inflation and median income trends."
)

if not (os.path.exists(HIST_PATH) and os.path.exists(FORECAST_PATH)):
    st.error(
        "Processed data not found. Run the pipeline first:\n\n"
        "```\npython src/data_ingestion.py\n"
        "python src/preprocessing.py\n"
        "python src/baseline_model.py\n```"
    )
    st.stop()

hist = pd.read_csv(HIST_PATH, parse_dates=["date"])
forecast = pd.read_csv(FORECAST_PATH, parse_dates=["date"])

col1, col2 = st.columns(2)
with col1:
    st.subheader("Historical Affordability Ratio")
    st.line_chart(hist.set_index("date")["affordability_ratio"])
with col2:
    st.subheader("10-Year Forecast (80% interval)")
    st.line_chart(
        forecast.set_index("date")[
            ["affordability_ratio_forecast", "lower_80", "upper_80"]
        ]
    )

st.divider()
st.subheader("🔍 Personalized Projection")

c1, c2, c3 = st.columns(3)
with c1:
    income = st.number_input("Your annual income ($)", value=90000, step=5000)
with c2:
    home_value = st.number_input("Target home value ($)", value=750000, step=25000)
with c3:
    rate = st.number_input(
        "Assumed mortgage rate (%)",
        value=float(hist["mortgage_rate_30yr"].iloc[-1]),
        step=0.1,
    )

payment = monthly_mortgage_payment(home_value, rate)
ratio = payment / (income / 12)

st.metric("Estimated Monthly Payment", f"${payment:,.0f}")
st.metric(
    "Affordability Ratio (payment / monthly income)",
    f"{ratio:.1%}",
    delta="Above the common 28% guideline" if ratio > 0.28 else "Within the common 28% guideline",
    delta_color="inverse",
)
