# NYC Mortgage Affordability Forecaster

Forecasting the 10-year trajectory of mortgage affordability in New York City by
modeling the interaction between **mortgage rates**, **inflation (CPI)**, and
**median household income**.

## Motivation

Mortgage affordability is not driven by home prices alone — it's a function of
borrowing cost, purchasing power erosion, and income growth moving at different
speeds. This project builds a reproducible pipeline that:

1. Pulls public macroeconomic and housing time series for NYC
2. Derives an **Affordability Ratio** = (estimated monthly mortgage payment) / (monthly median income)
3. Forecasts that ratio 10 years forward using classical and ML time-series models
4. Surfaces results through an interactive dashboard

## Data Sources

| Series | Source | Frequency |
|---|---|---|
| 30-Year Fixed Mortgage Rate | FRED (`MORTGAGE30US`) | Weekly |
| CPI, NY-Newark-Jersey City metro | BLS / FRED (`CUURA101SA0`) | Monthly |
| Median Household Income, NY | FRED (`MEHOINUSNY`) / Census ACS | Annual |
| Zillow Home Value Index (NYC) | Zillow Research | Monthly |

All series are pulled via the free [FRED API](https://fred.stlouisfed.org/docs/api/fred/)
and Zillow's public CSV exports — no paid data required. See `src/data_ingestion.py`.

> **No FRED API key?** The ingestion script falls back to bundled sample data in
> `data/raw/sample_fred_data.csv` so the pipeline runs end-to-end out of the box.

## Methodology

| Stage | Model | Purpose |
|---|---|---|
| Baseline | Linear trend / naive persistence | Sanity-check floor |
| Mid-tier | SARIMAX with exogenous regressors (inflation, income) | Interpretable, statistically grounded forecast |
| Advanced (stretch) | LSTM multivariate forecaster | Captures nonlinear interactions |

Validation uses **walk-forward (expanding window) validation**, not a random
train/test split — standard practice for time series, since random splits leak
future information into training.

## Repo Structure

```
nyc-mortgage-forecaster/
├── data/
│   ├── raw/                 # Downloaded/sample source series
│   └── processed/           # Merged, cleaned analysis-ready dataset
├── src/
│   ├── data_ingestion.py    # Pulls FRED + Zillow data (or loads sample fallback)
│   ├── preprocessing.py     # Aligns frequencies, computes affordability ratio
│   ├── baseline_model.py    # SARIMAX forecasting pipeline
│   └── evaluate.py          # Walk-forward validation + metrics
├── notebooks/
│   └── 01_exploration.ipynb # EDA starter notebook
├── app/
│   └── dashboard.py         # Streamlit affordability explorer
├── tests/
│   └── test_preprocessing.py
├── requirements.txt
└── README.md
```

## Quickstart

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# 1. Get data (uses sample fallback if no FRED_API_KEY set)
python src/data_ingestion.py

# 2. Build the analysis-ready dataset
python src/preprocessing.py

# 3. Fit the SARIMAX baseline and forecast 10 years out
python src/baseline_model.py

# 4. Launch the interactive dashboard
streamlit run app/dashboard.py
```

To use live data, get a free key at https://fred.stlouisfed.org/docs/api/api_key.html
and set it:
```bash
export FRED_API_KEY=your_key_here
```

## Limitations

- CPI and income series are available at coarser granularity than mortgage
  rates; the pipeline forward-fills lower-frequency series, which smooths
  short-term shocks.
- The model assumes historical relationships between rates/inflation/income
  hold forward — it will not anticipate discrete policy shocks (e.g. a sudden
  Fed rate change or rezoning policy).
- Affordability ratio uses a simplified mortgage formula (30-yr fixed, 20% down
  assumption) — see `src/preprocessing.py` for exact assumptions.
- Median income data for NYC specifically (vs. NY State) is only available
  annually via Census ACS, which caps forecast resolution.

## Possible Extensions

- Compare NYC affordability trends against another metro (e.g. Oslo or
  Stockholm) to study how affordability dynamics differ under different
  housing/tax policy regimes.
- Add SHAP value analysis to explain which macro factor dominates predictions
  in different forecast windows.
- Swap the SARIMAX baseline for a Temporal Fusion Transformer for
  probabilistic, multi-horizon forecasts with attention-based interpretability.

## License

MIT — see `LICENSE`.
