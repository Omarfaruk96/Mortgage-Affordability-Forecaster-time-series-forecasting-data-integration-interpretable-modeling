"""
evaluate.py
-----------
Walk-forward (expanding window) validation for the SARIMAX baseline.
This avoids the data leakage a random train/test split would cause in a
time-series setting.

Usage:
    python src/evaluate.py
"""

import os
import numpy as np
import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error

PROCESSED_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")
INPUT_PATH = os.path.join(PROCESSED_DIR, "affordability_dataset.csv")

MIN_TRAIN_SIZE = 6  # minimum years of history before the first forecast


def walk_forward_validate(df: pd.DataFrame) -> pd.DataFrame:
    endog = df["affordability_ratio"]
    exog = df[["cpi_index", "median_income_ny"]]

    results = []
    for cutoff in range(MIN_TRAIN_SIZE, len(df) - 1):
        train_endog = endog.iloc[:cutoff]
        train_exog = exog.iloc[:cutoff]
        test_exog = exog.iloc[cutoff:cutoff + 1]
        actual = endog.iloc[cutoff]

        model = SARIMAX(
            train_endog, exog=train_exog, order=(1, 1, 1),
            enforce_stationarity=False, enforce_invertibility=False,
        )
        fit = model.fit(disp=False)
        pred = fit.get_forecast(steps=1, exog=test_exog).predicted_mean.iloc[0]

        results.append({"cutoff_index": cutoff, "actual": actual, "predicted": pred})

    return pd.DataFrame(results)


def main():
    df = pd.read_csv(INPUT_PATH, parse_dates=["date"]).sort_values("date")

    if len(df) <= MIN_TRAIN_SIZE + 1:
        print(
            f"Not enough history ({len(df)} rows) for walk-forward validation "
            f"with MIN_TRAIN_SIZE={MIN_TRAIN_SIZE}. Add more years of data."
        )
        return

    results = walk_forward_validate(df)
    mae = mean_absolute_error(results["actual"], results["predicted"])
    mape = mean_absolute_percentage_error(results["actual"], results["predicted"])

    print(results)
    print(f"\nWalk-forward MAE:  {mae:.4f}")
    print(f"Walk-forward MAPE: {mape:.2%}")


if __name__ == "__main__":
    main()
