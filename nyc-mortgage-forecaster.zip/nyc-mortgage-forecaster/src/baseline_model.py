"""
baseline_model.py
------------------
Fits a SARIMAX model on the Affordability Ratio using inflation (CPI index)
and median income growth as exogenous regressors, then forecasts 10 years
(annual steps) forward.

Exogenous variables for the forecast horizon are extrapolated with simple
linear trends fit on historical data — replace with your own economic
assumptions (e.g. Fed rate path, CBO inflation projections) for a more
rigorous forward scenario.

Usage:
    python src/baseline_model.py
"""

import os
import numpy as np
import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX

PROCESSED_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")
INPUT_PATH = os.path.join(PROCESSED_DIR, "affordability_dataset.csv")
OUTPUT_PATH = os.path.join(PROCESSED_DIR, "forecast_10yr.csv")

FORECAST_YEARS = 10


def extrapolate_linear(series: pd.Series, n_steps: int) -> np.ndarray:
    """Simple linear-trend extrapolation for an exogenous regressor."""
    x = np.arange(len(series))
    coeffs = np.polyfit(x, series.values, deg=1)
    future_x = np.arange(len(series), len(series) + n_steps)
    return np.polyval(coeffs, future_x)


def main():
    df = pd.read_csv(INPUT_PATH, parse_dates=["date"]).sort_values("date")
    df = df.set_index("date")

    endog = df["affordability_ratio"]
    exog = df[["cpi_index", "median_income_ny"]]

    model = SARIMAX(
        endog,
        exog=exog,
        order=(1, 1, 1),
        seasonal_order=(0, 0, 0, 0),
        enforce_stationarity=False,
        enforce_invertibility=False,
    )
    fit = model.fit(disp=False)
    print(fit.summary())

    future_cpi = extrapolate_linear(df["cpi_index"], FORECAST_YEARS)
    future_income = extrapolate_linear(df["median_income_ny"], FORECAST_YEARS)
    future_exog = pd.DataFrame(
        {"cpi_index": future_cpi, "median_income_ny": future_income}
    )

    forecast = fit.get_forecast(steps=FORECAST_YEARS, exog=future_exog)
    forecast_mean = forecast.predicted_mean
    conf_int = forecast.conf_int(alpha=0.2)  # 80% interval

    last_year = df.index[-1].year
    future_dates = pd.date_range(
        start=f"{last_year + 1}-01-01", periods=FORECAST_YEARS, freq="YS"
    )

    result = pd.DataFrame(
        {
            "date": future_dates,
            "affordability_ratio_forecast": forecast_mean.values,
            "lower_80": conf_int.iloc[:, 0].values,
            "upper_80": conf_int.iloc[:, 1].values,
        }
    )

    os.makedirs(PROCESSED_DIR, exist_ok=True)
    result.to_csv(OUTPUT_PATH, index=False)
    print(f"\nSaved {FORECAST_YEARS}-year forecast to {OUTPUT_PATH}")
    print(result)


if __name__ == "__main__":
    main()
