"""
preprocessing.py
-----------------
Turns the raw merged macro dataset into an analysis-ready dataset by
computing the core target variable: the Affordability Ratio.

Affordability Ratio assumptions (documented here for transparency — see
README "Limitations"):
    - 30-year fixed mortgage
    - 20% down payment
    - Home price proxied by a fixed NYC median-home-value multiple of income
      when Zillow data isn't available (override with real ZHVI data by
      populating data/raw/zhvi_nyc.csv with columns: date, home_value)

Usage:
    python src/preprocessing.py
"""

import os
import pandas as pd

RAW_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
PROCESSED_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")

MERGED_INPUT = os.path.join(RAW_DIR, "merged_macro_data.csv")
ZHVI_INPUT = os.path.join(RAW_DIR, "zhvi_nyc.csv")  # optional, user-supplied
OUTPUT_PATH = os.path.join(PROCESSED_DIR, "affordability_dataset.csv")

# Fallback: assume NYC median home value is ~9x median household income
# when no ZHVI series is supplied. Override by adding data/raw/zhvi_nyc.csv.
DEFAULT_HOME_VALUE_INCOME_MULTIPLE = 9.0


def monthly_mortgage_payment(home_value: float, rate_pct: float, down_pct: float = 0.20,
                              years: int = 30) -> float:
    """Standard amortized monthly payment formula."""
    principal = home_value * (1 - down_pct)
    monthly_rate = (rate_pct / 100) / 12
    n_payments = years * 12
    if monthly_rate == 0:
        return principal / n_payments
    payment = principal * (monthly_rate * (1 + monthly_rate) ** n_payments) / \
        ((1 + monthly_rate) ** n_payments - 1)
    return payment


def build_dataset() -> pd.DataFrame:
    df = pd.read_csv(MERGED_INPUT, parse_dates=["date"])

    if os.path.exists(ZHVI_INPUT):
        zhvi = pd.read_csv(ZHVI_INPUT, parse_dates=["date"])
        df = df.merge(zhvi, on="date", how="left")
        df["home_value"] = df["home_value"].ffill()
    else:
        df["home_value"] = df["median_income_ny"] * DEFAULT_HOME_VALUE_INCOME_MULTIPLE

    df["monthly_payment"] = df.apply(
        lambda r: monthly_mortgage_payment(r["home_value"], r["mortgage_rate_30yr"]),
        axis=1,
    )
    df["monthly_income"] = df["median_income_ny"] / 12
    df["affordability_ratio"] = df["monthly_payment"] / df["monthly_income"]

    # Inflation-adjust the ratio using CPI (rebased to first available year = 100)
    df["cpi_index"] = df["cpi_ny_metro"] / df["cpi_ny_metro"].iloc[0] * 100

    return df


def main():
    os.makedirs(PROCESSED_DIR, exist_ok=True)
    df = build_dataset()
    df.to_csv(OUTPUT_PATH, index=False)
    print(f"Saved analysis-ready dataset ({len(df)} rows) to {OUTPUT_PATH}")
    print(df[["date", "affordability_ratio"]].tail())


if __name__ == "__main__":
    main()
