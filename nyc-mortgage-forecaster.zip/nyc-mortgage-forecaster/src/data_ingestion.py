"""
data_ingestion.py
------------------
Pulls macroeconomic time series needed for the NYC mortgage affordability
forecast:
    - 30-Year Fixed Mortgage Rate      (FRED: MORTGAGE30US)
    - CPI, NY-Newark-Jersey City metro (FRED: CUURA101SA0)
    - Median Household Income, NY      (FRED: MEHOINUSNY)

If no FRED_API_KEY environment variable is set, falls back to the bundled
sample dataset at data/raw/sample_fred_data.csv so the rest of the pipeline
still runs end-to-end.

Usage:
    python src/data_ingestion.py
"""

import os
import sys
import pandas as pd
import requests

RAW_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
SAMPLE_FALLBACK = os.path.join(RAW_DIR, "sample_fred_data.csv")

FRED_SERIES = {
    "mortgage_rate_30yr": "MORTGAGE30US",
    "cpi_ny_metro": "CUURA101SA0",
    "median_income_ny": "MEHOINUSNY",
}

FRED_BASE_URL = "https://api.stlouisfed.org/fred/series/observations"


def fetch_fred_series(series_id: str, api_key: str) -> pd.DataFrame:
    """Fetch one FRED series as a tidy date/value dataframe."""
    params = {
        "series_id": series_id,
        "api_key": api_key,
        "file_type": "json",
    }
    resp = requests.get(FRED_BASE_URL, params=params, timeout=30)
    resp.raise_for_status()
    obs = resp.json()["observations"]
    df = pd.DataFrame(obs)[["date", "value"]]
    df["date"] = pd.to_datetime(df["date"])
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    return df.dropna()


def fetch_all_live(api_key: str) -> pd.DataFrame:
    """Fetch and merge all FRED series into one wide dataframe (annual resample)."""
    frames = []
    for col_name, series_id in FRED_SERIES.items():
        print(f"Fetching {series_id} -> {col_name} ...")
        df = fetch_fred_series(series_id, api_key)
        df = df.set_index("date")["value"].resample("YS").mean().rename(col_name)
        frames.append(df)
    merged = pd.concat(frames, axis=1).dropna().reset_index()
    merged = merged.rename(columns={"index": "date"})
    return merged


def load_sample_fallback() -> pd.DataFrame:
    print(f"No FRED_API_KEY found — loading bundled sample data from {SAMPLE_FALLBACK}")
    df = pd.read_csv(SAMPLE_FALLBACK, parse_dates=["date"])
    return df


def main():
    os.makedirs(RAW_DIR, exist_ok=True)
    api_key = os.environ.get("FRED_API_KEY")

    if api_key:
        try:
            df = fetch_all_live(api_key)
        except Exception as e:
            print(f"Live fetch failed ({e}); falling back to sample data.", file=sys.stderr)
            df = load_sample_fallback()
    else:
        df = load_sample_fallback()

    out_path = os.path.join(RAW_DIR, "merged_macro_data.csv")
    df.to_csv(out_path, index=False)
    print(f"Saved {len(df)} rows to {out_path}")


if __name__ == "__main__":
    main()
